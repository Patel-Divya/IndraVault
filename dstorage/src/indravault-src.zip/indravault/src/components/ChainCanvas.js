import React, { useEffect, useRef } from 'react';

const NUM_NODES  = 14;
const NUM_PARTS  = 18;
const HEX_CHARS  = '0123456789ABCDEF';

function makeNode(w, h) {
  return {
    x:  Math.random() * w,
    y:  Math.random() * h,
    vx: (Math.random() - 0.5) * 0.35,
    vy: (Math.random() - 0.5) * 0.35,
    size:  14 + Math.random() * 18,
    hue:   Math.random() > 0.5 ? 'gold' : 'cyan',
    pulse: Math.random() * Math.PI * 2,
    pulseSpeed: 0.007 + Math.random() * 0.006,
  };
}

function makeParticle(num) {
  const a = Math.floor(Math.random() * num);
  let b = Math.floor(Math.random() * num);
  if (b === a) b = (a + 1) % num;
  return { from: a, to: b, t: Math.random(), speed: 0.003 + Math.random() * 0.004 };
}

export default function ChainCanvas() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx    = canvas.getContext('2d');
    let raf;
    let nodes, particles, drops, cols;

    function resize() {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      cols  = Math.floor(canvas.width / 22);
      drops = Array.from({ length: cols }, () => Math.random() * -50);

      if (!nodes) {
        nodes     = Array.from({ length: NUM_NODES }, () => makeNode(canvas.width, canvas.height));
        particles = Array.from({ length: NUM_PARTS  }, () => makeParticle(NUM_NODES));
      }
    }

    function drawHexRain() {
      ctx.fillStyle = 'rgba(3,5,8,0.18)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = '11px "Share Tech Mono", monospace';
      drops.forEach((y, i) => {
        const ch    = HEX_CHARS[Math.floor(Math.random() * 16)];
        const alpha = Math.random() * 0.28 + 0.04;
        ctx.fillStyle = `rgba(201,168,76,${alpha})`;
        ctx.fillText(ch, i * 22, y * 22);
        drops[i] = (y > canvas.height / 22 && Math.random() > 0.975) ? 0 : y + 0.5;
      });
    }

    function drawConnections() {
      for (let i = 0; i < NUM_NODES; i++) {
        for (let j = i + 1; j < NUM_NODES; j++) {
          const dx   = nodes[i].x - nodes[j].x;
          const dy   = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > 280) continue;
          const alpha = (1 - dist / 280) * 0.28;
          ctx.beginPath();
          ctx.setLineDash([4, 8]);
          ctx.strokeStyle = `rgba(201,168,76,${alpha})`;
          ctx.lineWidth   = 0.8;
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
    }

    function drawNodes() {
      nodes.forEach(n => {
        n.pulse += n.pulseSpeed;
        const glow  = 0.5 + 0.5 * Math.sin(n.pulse);
        const isGold = n.hue === 'gold';
        const color      = isGold ? `rgba(201,168,76,${0.5 + glow * 0.4})` : `rgba(0,229,255,${0.4 + glow * 0.4})`;
        const glowColor  = isGold ? `rgba(201,168,76,${0.1  + glow * 0.1})` : `rgba(0,229,255,${0.08 + glow * 0.1})`;

        // outer glow
        const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.size * 3);
        grad.addColorStop(0, glowColor);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.size * 3, 0, Math.PI * 2);
        ctx.fill();

        // block square
        const hs = n.size * 0.5;
        ctx.strokeStyle = color;
        ctx.lineWidth   = 1.2;
        ctx.strokeRect(n.x - hs, n.y - hs, n.size, n.size);

        // inner crosshair
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        ctx.moveTo(n.x - hs, n.y); ctx.lineTo(n.x + hs, n.y);
        ctx.moveTo(n.x, n.y - hs); ctx.lineTo(n.x, n.y + hs);
        ctx.stroke();

        // centre dot
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(n.x, n.y, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // move + wrap
        n.x += n.vx; n.y += n.vy;
        if (n.x < -50)              n.x = canvas.width  + 50;
        if (n.x > canvas.width + 50) n.x = -50;
        if (n.y < -50)              n.y = canvas.height + 50;
        if (n.y > canvas.height + 50) n.y = -50;
      });
    }

    function drawParticles() {
      particles.forEach((p, idx) => {
        const a  = nodes[p.from];
        const b  = nodes[p.to];
        const px = a.x + (b.x - a.x) * p.t;
        const py = a.y + (b.y - a.y) * p.t;

        ctx.fillStyle = 'rgba(0,229,255,0.9)';
        ctx.beginPath(); ctx.arc(px, py, 2.8, 0, Math.PI * 2); ctx.fill();

        ctx.fillStyle = 'rgba(0,229,255,0.18)';
        ctx.beginPath(); ctx.arc(px, py, 6, 0, Math.PI * 2); ctx.fill();

        p.t += p.speed;
        if (p.t >= 1) particles[idx] = makeParticle(NUM_NODES);
      });
    }

    function loop() {
      drawHexRain();
      drawConnections();
      drawNodes();
      drawParticles();
      raf = requestAnimationFrame(loop);
    }

    resize();
    window.addEventListener('resize', resize);
    document.fonts.ready.then(() => { raf = requestAnimationFrame(loop); });

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="chain-canvas"
      style={{ position:'fixed', inset:0, zIndex:0, pointerEvents:'none', opacity:0.5 }}
    />
  );
}
