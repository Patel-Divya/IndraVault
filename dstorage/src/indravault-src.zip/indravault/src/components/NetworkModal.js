import React from 'react';

/**
 * NetworkModal
 * Props:
 *   isOpen     – bool
 *   icon       – emoji string
 *   title      – string
 *   body       – string
 *   onClose    – fn
 *   onRetry    – fn (optional — shows retry button if provided)
 */
export default function NetworkModal({ isOpen, icon, title, body, onClose, onRetry }) {
  if (!isOpen) return null;

  return (
    <div className="iv-modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="iv-modal-box">
        <span className="iv-modal-icon">{icon || '⚠️'}</span>
        <div className="iv-modal-title">{title}</div>
        <div className="iv-modal-body">{body}</div>
        <div className="iv-modal-actions">
          <button className="iv-modal-btn-close" onClick={onClose}>DISMISS</button>
          {onRetry && (
            <button className="iv-modal-btn-retry" onClick={onRetry}>RETRY</button>
          )}
        </div>
      </div>
    </div>
  );
}
