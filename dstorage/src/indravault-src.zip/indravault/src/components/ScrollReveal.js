import { useEffect, useRef } from 'react';

/**
 * useScrollReveal – attaches IntersectionObserver to add 'visible' class.
 * Usage: const ref = useScrollReveal();  <div ref={ref} className="reveal">…</div>
 */
export function useScrollReveal(threshold = 0.12) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add('visible'); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);

  return ref;
}

/**
 * RevealSection – wraps children in a reveal div.
 * Props: delay (ms string, e.g. '0.2s'), className
 */
export function RevealSection({ children, delay = '0s', className = '' }) {
  const ref = useScrollReveal();
  return (
    <div
      ref={ref}
      className={`reveal ${className}`}
      style={{ transitionDelay: delay }}
    >
      {children}
    </div>
  );
}
