import React, { useRef } from 'react';

/**
 * MagneticButton
 * Props: className, onClick, children, disabled, type
 * Pulls toward the cursor within its bounding box.
 */
export default function MagneticButton({ className, onClick, children, disabled, type = 'button', strength = 0.35 }) {
  const ref = useRef(null);

  const handleMove = (e) => {
    const el   = ref.current;
    const rect = el.getBoundingClientRect();
    const cx   = rect.left + rect.width  / 2;
    const cy   = rect.top  + rect.height / 2;
    const dx   = (e.clientX - cx) * strength;
    const dy   = (e.clientY - cy) * strength;
    el.style.transform = `translate(${dx}px, ${dy}px)`;
  };

  const handleLeave = () => {
    ref.current.style.transform = 'translate(0, 0)';
  };

  return (
    <button
      ref={ref}
      type={type}
      className={className}
      onClick={onClick}
      disabled={disabled}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ transition: 'transform 0.15s ease, box-shadow 0.3s' }}
    >
      {children}
    </button>
  );
}
