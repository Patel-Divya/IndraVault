import React, { useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { shortAddr } from '../helpers';

// ── Scramble text effect ────────────────────────────────────
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789⬡◈▸△';

function scramble(el, target, iterations = 22) {
  let iter = 0;
  const iv = setInterval(() => {
    el.textContent = target.split('').map((c, i) =>
      i < (iter / iterations) * target.length
        ? c
        : CHARS[Math.floor(Math.random() * CHARS.length)]
    ).join('');
    iter++;
    if (iter > iterations) { el.textContent = target; clearInterval(iv); }
  }, 32);
}

/**
 * Props:
 *   account      – string (wallet address)
 *   networkOnline – bool
 */
export default function Navbar({ account, networkOnline }) {
  const logoRef  = useRef(null);
  const location = useLocation();

  // Scramble logo on mount
  useEffect(() => {
    const el = logoRef.current;
    if (!el) return;
    const t = setTimeout(() => scramble(el, 'INDRA▸VAULT', 26), 500);
    return () => clearTimeout(t);
  }, []);

  // Identicon via canvas
  let identiconSrc = null;
  if (account && window.Identicon) {
    try { identiconSrc = `data:image/png;base64,${new window.Identicon(account, 28).toString()}`; }
    catch (_) { /* no identicon lib */ }
  }

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <nav className="iv-navbar">
      {/* Logo */}
      <Link to="/" className="iv-nav-logo">
        <span ref={logoRef}>INDRA<span>▸</span>VAULT</span>
      </Link>

      {/* Nav links */}
      <div className="iv-nav-links">
        <Link to="/" className={`iv-nav-link ${location.pathname === '/' ? 'active' : ''}`}>
          HOME
        </Link>
        <Link to="/vault" className={`iv-nav-link ${isActive('/vault') ? 'active' : ''}`}>
          VAULT
        </Link>
      </div>

      {/* Right side */}
      <div className="iv-nav-right">
        {/* Network status — online ONLY when wallet + correct network */}
        <div className={`net-pill ${networkOnline ? 'online' : 'offline'}`}>
          <div className="net-dot" />
          <span>{networkOnline ? 'NETWORK ONLINE' : 'OFFLINE'}</span>
        </div>

        {/* Account badge */}
        <div className="account-badge">
          {shortAddr(account)}
        </div>

        {/* Identicon (only if library available) */}
        {identiconSrc && (
          <img className="nav-identicon" src={identiconSrc} alt="wallet" />
        )}
      </div>
    </nav>
  );
}
